<div class="top-bar" id="top-bar">
	<div class="container">
		<div class="row row-flex-center">
            <div class="col-md-3 text-left">
                <span>HOTLINE: <?php echo option::get('contact_phone');?></span>
            </div>
			<div class="col-md-6 welcome text-center">
				<span><?php echo option::get('top_bar_text');?></span>
			</div>
            <div class="col-md-3 text-right">
                <a class="btn-search js_btn_panel__sidebar" href="#search-sidebar"><i class="fal fa-search"></i></a>
            </div>
		</div>
	</div>
</div>